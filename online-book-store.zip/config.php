<?php

$conn = mysqli_connect('localhost','root','','book-store') or die('connection failed');

?>